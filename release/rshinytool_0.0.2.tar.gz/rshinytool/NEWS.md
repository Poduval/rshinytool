# Changes in version 0.0.2

* Updated package structure

# Changes in version 0.0.1

* Added 2 demo shiny dashboards 
