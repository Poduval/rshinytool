# Changes in version 0.0.1

  * Added 2 demo shiny dashboards 
